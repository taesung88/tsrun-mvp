import React from 'react';
import Login from './components/Login';
import WorkoutInput from './components/WorkoutInput';
import Feed from './components/Feed';

function App() {
  return (
    <div>
      <h1>🏃‍♂️ TS RUN</h1>
      <Login />
      <WorkoutInput />
      <Feed />
    </div>
  );
}

export default App;
