import React from 'react';

export default function Comments() {
  return (
    <div>
      <h3>댓글</h3>
      <input placeholder="댓글을 입력하세요" />
      <button>댓글 작성</button>
    </div>
  );
}
