import React from 'react';
import Comments from './Comments';

export default function Feed() {
  return (
    <div>
      <h2>러닝 피드</h2>
      <p>친구들의 러닝 기록이 여기 표시됩니다.</p>
      <Comments />
    </div>
  );
}
