import React from 'react';

export default function InviteFriend() {
  return (
    <div>
      <h2>친구 초대</h2>
      <button>초대 링크 복사</button>
    </div>
  );
}
