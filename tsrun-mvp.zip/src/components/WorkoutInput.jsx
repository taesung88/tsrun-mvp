import React from 'react';

export default function WorkoutInput() {
  return (
    <div>
      <h2>오늘의 러닝</h2>
      <input placeholder="몇 km 뛰었나요?" />
      <button>기록하기</button>
    </div>
  );
}
